##############################################################################
## Copyright (c) 2006, 2007 Xilinx, Inc.
## This design is confidential and proprietary of Xilinx, All Rights Reserved.
##############################################################################
##   ____  ____
##  /   /\/   /
## /___/  \  /   Vendor:        Xilinx
## \   \   \/    Version:       1.0.1
##  \   \        Filenames:     at45db161.mcs, st25p16.mcs
##  /   /        Filenames:     xcf04s.mcs, m29dw323.mcs
## /___/   /\    Date Created:  December 25, 2006
## \   \  /  \   Last Modified: April 1, 2007
##  \___\/\___\
##
## Devices:   Spartan-3 Generation FPGA
## Purpose:   Out-of-Box images for Spartan-3A / Spartan-3AN Starter Kit
## Contact:   crabill@xilinx.com
## Reference: None
##
## Revision History:
##   Rev 1.0.0 - (crabill) Created December 25, 2006 for PCB revision C.
##   Rev 1.0.1 - (crabill) Modified April 1, 2007 to mention revision D
##                         of the PCB and applicability to Spartan-3AN.
##
##############################################################################
##
## LIMITED WARRANTY AND DISCLAIMER. These designs are provided to you "as is".
## Xilinx and its licensors make and you receive no warranties or conditions,
## express, implied, statutory or otherwise, and Xilinx specifically disclaims
## any implied warranties of merchantability, non-infringement, or fitness for
## a particular purpose. Xilinx does not warrant that the functions contained
## in these designs will meet your requirements, or that the operation of
## these designs will be uninterrupted or error free, or that defects in the
## designs will be corrected. Furthermore, Xilinx does not warrant or make any
## representations regarding use or the results of the use of the designs in
## terms of correctness, accuracy, reliability, or otherwise.
##
## LIMITATION OF LIABILITY. In no event will Xilinx or its licensors be liable
## for any loss of data, lost profits, cost or procurement of substitute goods
## or services, or for any special, incidental, consequential, or indirect
## damages arising from the use or operation of the designs or accompanying
## documentation, however caused and on any theory of liability. This
## limitation will apply even if Xilinx has been advised of the possibility
## of such damage. This limitation shall apply not-withstanding the failure
## of the essential purpose of any limited remedies herein.
##
##############################################################################
## Copyright (c) 2006, 2007 Xilinx, Inc.
## This design is confidential and proprietary of Xilinx, All Rights Reserved.
##############################################################################

The board is shipped with all four non-volatile memory devices pre-programmed.
If you wish to restore the board to its original configuration, follow these
steps.

*	Remove ALL jumpers

*	Install jumpers at J9, J10, J11, J12, J13, J40, J41, and J42 to
	connect the power supplies

*	Install three jumpers on J26 as shown on the board to select master
	serial configuration mode

*	Install one jumper on J46, connecting CE_PROM to GND to enable the
	Platform Flash device

*	Turn on power; use iMPACT in JTAG mode to program xcf04s device
	with xcf04s.mcs file

*	At this point, you may cycle power or press the PROG button to
	confirm the board test design loads from the Platform Flash using
	master serial configuration mode

*	Remove the jumper from J46 to disable the Platform Flash device

*	Install one jumper on J16 to hold PROG# asserted for DirectSPI
	programming in iMPACT

*	Install two jumpers on J1, so they are horizontal, selecting the ST
	serial flash for SPI configuration

*	Install four jumpers, shorting J25 to J23 as shown on the board, to
	enable DirectSPI programming

*	Use iMPACT in DirectSPI mode to program m25p16 device with st25p16.mcs
	file

*	Rotate jumpers on J1 by 90 degrees, so they are vertical, selecting
	the Atmel serial flash for SPI configuration

*	Use iMPACT in DirectSPI mode to program at45db161d device with
	at45db161.mcs file

*	Remove one jumper from J26, to select SPI configuration mode, as
	shown on the board

*	Remove the four jumpers that short J25 to J23

*	Connect the RS232 DCE port on the board to a PC using a standard
	serial cable and open the supplied HyperTerminal session

*	Remove the jumper on J16 to de-assert PROG#

*	In HyperTerminal, press the �4� key to initiate a MultiBoot to the
	parallel flash programmer

*	In HyperTerminal, press �E� to erase the parallel flash.  Press �Y� to
	confirm the erase

*	In Hyperterminal, press �P� to program the device

*	Use �Send Text File� from the HyperTerminal Transfer menu, enable the
	file filter to show �All files (*.*)� and select the m29dw323.mcs file

*	The programming may take up to 30 minutes

*	When parallel flash programming is complete, press the rotary knob

*	The board is now restored to the original state and the power-on demo
	should be running

If you have a Spartan-3AN Starter Kit, you may also want/need to restore the
ISF demo design; consult the demo design documentation on the Spartan-3AN
Reference Design web page.