This folder has the batch files to synthesize using the XST or Synplify Pro
and PAR the design through command mode.

Steps to run the design using the ise_flow (batch mode):

1. Executing the ise_flow.bat file, synthesizes the design using
   XST or Synplify Pro and does the PAR.
   On running "ise_flow.bat" file, removes the XST/Synplify Pro report
   files first (if exist any on previous runs) and then does
   implementation of the design.

2. On running the ise_flow.bat file, creates the all report files.

Steps to run the design using the create_ise (GUI mode - for XST cases only):

1. This file will appear for XST cases only.

2. On executing the "create_ise.bat" file creates "test.xise" project file
   and set all the properties of the design selected.

3. The design can be implemented in ISE Projnav GUI by invoking
   the "test.xise" project file.

4. In Linux operating systems, test.xise project can be invoked by executing
   the command 'ise test.xise' from the terminal.

About other files in PAR folder :

* vhdl_bl4.ucf file is the constratint file for the design. This is used
  by ISE tool during PAR phase. It has all the clock constraints,
  Location constraints, false paths if any, IO standards and
  Area group constraints if any.

* ise_run.txt file has synthesis options for the XST tool.
  This file is used for batch mode.

* mem_interface_top.ut file has the options for the Configuration file
  generation i.e. the .bit file.


* "set_ise_prop.tcl" file has all the properties that needs to be set
  in GUI mode. This file will appear only for XST cases.

* "icon_coregen.xco" and "ila_coregen.xco" files are used to
  generate chipscope ila and icon EDIF/NGC files. view the design signals
  on chipscope, you should port the design signals to chipscope modules
  i.e., ila and icon and set DEBUG_EN parameter to 1 in vhdl_bl4 rtl file.
  In order to generate the EDIF/NGC files, you must execute the following
  commands before starting systhesis and PAR.

        coregen -b ila_coregen.xco
        coregen -b icon_coregen.xco
        coregen -b vio_coregen.xco

Note : When you generate the design usign DEBUG_EN option, the above mentioned
       chipscope coregen commands are printed into ise_flow.bat and
       create_ise.bat files. The vhdl_bl4 rtl file will have the design
       debug signals portmapped to ila and icon chipscope modules.

* At the start of a Chip Scope Analyzer project, all of the signals in
  every core have generic names. "vhdl_bl4.cdc" is a file that contains
  all the signal names of all cores. Upon importing this file, signal names are
  renamed to the specified names in "vhdl_bl4.cdc" file. This file will work
  for the generated designs from MIG. If any of the design parameter values
  are changed after generating the design, this file will not work.

Synth folder:

* Synth folder has the constraint file for synplify Pro designs i.e.
  the .sdc file, Project file which has the design files to be added to
  the project i.e. the .prj file  and the synthesis tool options file for
  synplify Pro i.e. .tcl file.

Design without chipscope :

If the user wants to run the design without chipscope, following are the steps required 
to be done by the user.

1. Set the parameter DEBUG_EN to 0 in vhdl_bl4_parameters_0.vhd under rtl folder 
2. Comment out coregen commands in ise_flow.bat in par directory
3. Run ise_flow.bat
