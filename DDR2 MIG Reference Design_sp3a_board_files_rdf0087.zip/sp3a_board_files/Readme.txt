1. Spartan-3A Starter Kit supports DDR2 SDRAM(Components) memory design for 
   Spartan-3A FPGA xc3s700afg484.

2. Above mentioned design were generated at 133MHz clock frequency.

3. You should go through the readme files provided in the corresponding design
   folders before using the bit files for testing Spartan-3A Starter Kit.

4. All the designs use the 133MHz onboard clock source as the design clock 
   source. All designs are verified with ISE 12.2.

5. Steps to regenerate for other frequencies using SMA connector, 
   a) Uncomment the LOC constraints for external clock and comment 
      the on board clock in UCF file. 
        #NET  "sys_clk"	LOC = "V12"; # on board clock
        NET  "sys_clk"	LOC = "U12"; #external clock	
 
6. Users can also regenerate the bit files by running PAR with the help of
   ise_flow.bat batch file or create_ise.bat file provided in the correspondng
   design folders. Refer to the readme.txt file provided in the par folder of 
   the respective design folders.

7. When you simulate the VHDL designs, you will be reported a warning message 
   by Modelsim that "# ** Warning: (vsim-3473) Component instance 
   "i_icon : icon is not bound.". You can safely ignore this warning since 
   these component instances are used for probing internal design signals on 
   to Chipscope.

8. Please contact support.xilinx.com for Spartan-3A Starter Kit details.
