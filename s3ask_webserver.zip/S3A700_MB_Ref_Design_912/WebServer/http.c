/*
 * XILINX IS PROVIDING THIS DESIGN, CODE, OR INFORMATION "AS IS"
 * SOLELY FOR USE IN DEVELOPING PROGRAMS AND SOLUTIONS FOR
 * XILINX DEVICES.  BY PROVIDING THIS DESIGN, CODE, OR INFORMATION
 * AS ONE POSSIBLE IMPLEMENTATION OF THIS FEATURE, APPLICATION
 * OR STANDARD, XILINX IS MAKING NO REPRESENTATION THAT THIS
 * IMPLEMENTATION IS FREE FROM ANY CLAIMS OF INFRINGEMENT,
 * AND YOU ARE RESPONSIBLE FOR OBTAINING ANY RIGHTS YOU MAY REQUIRE
 * FOR YOUR IMPLEMENTATION.  XILINX EXPRESSLY DISCLAIMS ANY
 * WARRANTY WHATSOEVER WITH RESPECT TO THE ADEQUACY OF THE
 * IMPLEMENTATION, INCLUDING BUT NOT LIMITED TO ANY WARRANTIES OR
 * REPRESENTATIONS THAT THIS IMPLEMENTATION IS FREE FROM CLAIMS OF
 * INFRINGEMENT, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE.
 *
 * (c) Copyright 2005 Xilinx, Inc.
 * All rights reserved.
 *
 */

/*
 * Modification history:
 *    12/2005 - Rob Armstrong - Xilinx, Inc.
 *            - Initial File Version
 */

/* Xilinx Includes */
#include "mfs_config.h"
#include "http.h"
#include "xgpio.h"
#include "web_server.h"

/* C Library includes */
#include "string.h"          // Required for memset and strtok, strcpy, etc.

/* lwIP Includes */
#include "netif/xemacif.h"
#include "lwip/tcpip.h"
#include "lwip/memp.h"
#include "netif/etharp.h"
#include "lwip/sys.h"
#include "lwip/sockets.h"

/* External Instance Pointers for Xilinx Peripherals */
extern XGpio PushButtons;
extern XGpio LEDs;

/* void processGet(int socket, char *dataPtr)
 *
 * Respond to GET requests by serving the filename or a file not found
 * as appropriate
 */
void processGet(int socket, char *dataPtr)
{
    int status;
    int fd;
    int headerLength;
    int bytesRead;
    int len;
    long readTotal;
    long fileLength;
    char *extension;
    char fileName[STRING_BUFFER_SIZE];
    char sendBuffer[SEND_BUFFER_SIZE];
    char stringBuffer[STRING_BUFFER_SIZE];

    // If the data pointer is to /, replace it with index.html
    // If the filename is not /, also determine the file extension
    if(!strcmp(dataPtr, "/")) {
        strcpy(fileName, "index.html");
    }
    else {
        strcpy(fileName, dataPtr);
        extension = strtok(dataPtr, ".");
        extension = strtok((char *)NULL, ".");
        xil_printf("Extension is %s\r\n", extension);
    }

    // If the file extension is .xwscmd, process it as a command to the Xilinx
    // web server demo.
    if(!strncmp(extension, "xwscmd", 6)) {
        processCommand(socket, fileName);
        sprintf(fileName, "cmddata.%d", socket);
    }

    // Check to see if the specified file exists and, if not, send a
    // 404 file not found header
    status = mfs_exists_file(fileName);
    if(status == 0) {
        sendNotFound(socket);
        return;
    }
    // If the file exists, send it
    else {
        if((fd = mfs_file_open(fileName, MFS_MODE_READ)) == -1) {
            xil_printf("ERROR: Can't open %s\n\r", dataPtr);
            sendNotFound(socket);
            return;
        }
        xil_printf("File exists and is open\r\n");
    }

    // Determine the length of the file
    fileLength = mfs_file_lseek(fd, 0, MFS_SEEK_END);

    // Copy the header to the beginning of the send buffer
    strcpy(sendBuffer, "HTTP/1.1 200 OK\r\n");
    strcat(sendBuffer, "Content-type: ");
    // Determine the proper type of file being requested
    // Supported file types are GIF, JPG, and text/html
    if(!strcmp(extension, "jpg")) {
        strcat(sendBuffer, "image/jpeg");
    }
    else if(!strcmp(extension, "gif")) {
        strcat(sendBuffer, "image/gif");
    }
    else if(!strcmp(extension, "pdf")) {
        strcat(sendBuffer, "application/pdf");
    }
    else {
        strcat(sendBuffer, "text/html");
    }
    strcat(sendBuffer, "\r\n");
    sprintf(stringBuffer, "Content-length: %d\r\n", fileLength);
    strcat(sendBuffer, stringBuffer);
    strcat(sendBuffer, "Connection: Close\r\n\r\n");
    headerLength = strlen(sendBuffer);

    xil_printf("%s", sendBuffer);

    readTotal = 0;

    // Copy the file into the send buffer
    bytesRead = mfs_file_read(fd,
                              (char *)(sendBuffer + headerLength),
                              SEND_BUFFER_SIZE - headerLength);
    len = 0;
    while(len < (headerLength + bytesRead)) {
        len += write(socket, sendBuffer, headerLength + bytesRead);
    }

    readTotal += bytesRead;
    while(readTotal < fileLength) {
        len = 0;
        bytesRead = mfs_file_read(fd, sendBuffer, SEND_BUFFER_SIZE);
        //xil_printf("Read %d bytes\r\n", bytesRead);
        while(len < bytesRead) {
            len += write(socket, sendBuffer, bytesRead);
            //xil_printf("Sending - len: %d - bytes: %d\r\n", len, bytesRead);
        }
        readTotal += bytesRead;
    }

    // Close the file being sent
    mfs_file_close(fd);

    // If this was a command request, clean up by removing the results file
    // from the MFS
    if(!strncmp(extension, "xwscmd", 6)) {
        mfs_delete_file(fileName);
    }
}

/* void processCommand(int socket, char *commandPtr)
 *
 * The Xilinx Web Server reference design defines a set of commands that can
 * be interpreted by the application and pre-processed, similar to (but vastly
 * more simplified than) PHP, ASP, etc. The web server identifies these by
 * the file extension .xwscmd, which is preceded by the command.
 *
 * Example: GET /doSomething.xwscmd HTTP/1.1
 * would execute the fictional command doSomething and return the result
 *
 * This routine returns the data by creating a file in the MFS file system
 * containing the results. In order to make this thread safe, the socket FD
 * is appended to the filename so that if multiple requests are received at
 * once, the command responses for each file are not overwritten.
 */
void processCommand(int socket, char *commandPtr)
{
    char *command;
    char *data;
    char fileName[STRING_BUFFER_SIZE];
    char dataBuffer[SEND_BUFFER_SIZE];
    int fd;
    int status;
    int gpioData;

    // Separate the command issued from the .xwscmd extension
    command = strtok(commandPtr, ".");
    if(*command == '/') {
        command++;
    }

    // Parse out the data for the command (if any) supplied by a GET request
    if(commandPtr[strlen(command) + 8] == '?') {
        data = strtok(NULL, "=");
        data = strtok(NULL, " ");
    }

    // Format the file name for this command response and zero out the command
    // response buffer
    sprintf(fileName, "cmddata.%d", socket);
    memset(dataBuffer, 0, SEND_BUFFER_SIZE);

    // Create the file to contain the results of the command
    if((fd = mfs_file_open(fileName, MFS_MODE_CREATE)) == -1)
    {
        xil_printf("ERROR: Can't create %s\n\r", fileName);
        return;
    }
    if((status = mfs_file_close(fd)) == 0) {
		xil_printf("ERROR: Can't close the file %s\r\n", fileName);
	}
	if((fd = mfs_file_open(fileName, MFS_MODE_WRITE)) == -1)
    {
        xil_printf("ERROR: Can't open %s for writing\n\r", fileName);
        return;
    }

    // Parse the command and respond to it
    if(!strcmp(command, "switchesVal")) {
        // Respond with the current push button values
        gpioData = XGpio_DiscreteRead(&PushButtons, SWITCHES_CHANNEL);
        dataBuffer[0] = ((gpioData & 0x00000008) >> 3) + 48;
        dataBuffer[1] = ((gpioData & 0x00000004) >> 2) + 48;
        dataBuffer[2] = ((gpioData & 0x00000002) >> 1) + 48;
        dataBuffer[3] = (gpioData & 0x00000001) + 48;
    }
    else if(!strcmp(command, "setLED")) {
        setLEDCmd(data);
        strcpy(dataBuffer, "<html><head><title>Xilinx S3E Web Server</title>\r\n");
        strcat(dataBuffer, "<META HTTP-EQUIV=\"Refresh\" CONTENT=\"5; ");
        strcat(dataBuffer, "URL=index.html\"></head>\r\n<body bgcolor=\"#FFFFFF\">\r\n");
        strcat(dataBuffer, "The command has processed successfully! You will now be ");
        strcat(dataBuffer, "redirected back to index.html.</body></html>\r\n");
    }
    else {
        xil_printf("WARNING: Unknown command %s\r\n", command);
    }

    // Write the data for the command to the command file
    if(strlen(dataBuffer) != 0) {
        // Write an HTML header to the command file
        if((status = mfs_file_write(fd,
                                    "<html>\r\n<body>\r\n",
                                    strlen("<html>\r\n<body>\r\n"))) == 0) {
            xil_printf("ERROR: Can't write to %s\r\n", fileName);
        }
        if((status = mfs_file_write(fd, dataBuffer, strlen(dataBuffer))) == 0) {
            xil_printf("ERROR: Can't write to %s\r\n", fileName);
        }
        if((status = mfs_file_write(fd,
                                    "\r\n</body>\r\n</html>\r\n",
                                    strlen("\r\n</body>\r\n</html>\r\n"))) == 0) {
            xil_printf("ERROR: Can't write to %s\r\n", fileName);
        }
    }
    if((status = mfs_file_close(fd)) == 0) {
		xil_printf("ERROR: Can't close the file %s\r\n", fileName);
	}
}

/* void sendNotFound(int socket)
 *
 * If a requested file is not found on the ML40x web server, send the a
 * 404 file not found header and the file 404.html
 */
void sendNotFound(int socket)
{
    int fd;
    int headerLength;
    int bytesRead;
    int len;
    long readTotal;
    long fileLength;
    char sendBuffer[SEND_BUFFER_SIZE];
    char stringBuffer[STRING_BUFFER_SIZE];

    // Open 404.html from the MFS
    if((fd = mfs_file_open("404.html", MFS_MODE_READ)) == -1) {
        xil_printf("ERROR: Can't open 404.html\n\r");
        strcpy(sendBuffer, "HTTP/1.1 404 Not Found\r\n");
        strcat(sendBuffer, "Connection: Close\r\n\r\n");
        len = 0;
        while(len < strlen(sendBuffer)) {
            len += write(socket, sendBuffer, strlen(sendBuffer));
        }
    }

    // Determine the length of the file
    fileLength = mfs_file_lseek(fd, 0, MFS_SEEK_END);

    // Copy the header to the beginning of the send buffer
    strcpy(sendBuffer, "HTTP/1.1 404 Not Found\r\n");
    strcat(sendBuffer, "Content-type: text/html\r\n");
    sprintf(stringBuffer, "Content-length: %d\r\n", fileLength);
    strcat(sendBuffer, stringBuffer);
    strcat(sendBuffer, "Connection: Close\r\n\r\n");
    headerLength = strlen(sendBuffer);

    // Copy the file into the send buffer
    bytesRead = mfs_file_read(fd,
                              (char *)(sendBuffer + headerLength),
                              SEND_BUFFER_SIZE - headerLength);
    len = 0;
    while(len < (headerLength + bytesRead)) {
        len += write(socket, sendBuffer, headerLength + bytesRead);
    }

    readTotal = (long)bytesRead;
    while(readTotal < fileLength) {
        bytesRead = mfs_file_read(fd, sendBuffer, SEND_BUFFER_SIZE);
        len = 0;
        while(len < bytesRead) {
            len += write(socket, sendBuffer, bytesRead);
        }
        readTotal += bytesRead;
    }
    mfs_file_close(fd);
}

/* void setLEDCmd(char *data)
 *
 * Sets the LEDs to display a binary value
 */
void setLEDCmd(char *data)
{
    int gpioData;
    int data_input[2];
    int data_len;
    int position = 0;
    data_len = strlen(data);
    while (position < data_len) {
	    switch(data[position]) {
	        case '0':
	           data_input[position] = 0;
	           break;
	        case '1':
	           data_input[position] = 1;
	           break;
			case '2':
	           data_input[position] = 2;
	           break;
	        case '3':
	           data_input[position] = 3;
	           break;
	        case '4':
	           data_input[position] = 4;
	           break;
	        case '5':
	           data_input[position] = 5;
	           break;
	        case '6':
	           data_input[position] = 6;
	           break;
	        case '7':
	           data_input[position] = 7;
	           break;
	        case '8':
	           data_input[position] = 8;
	           break;
	        case '9':
	           data_input[position] = 9;
	           break;
	        case 'a': case 'A':
	           data_input[position] = 10;
	           break;
	        case 'b': case 'B':
	           data_input[position] = 11;
	           break;
	        case 'c': case 'C':
	           data_input[position] = 12;
	           break;
	        case 'd': case 'D':
	           data_input[position] = 13;
	           break;
	        case 'e': case 'E':
	           data_input[position] = 14;
	           break;
	        case 'f': case 'F':
	           data_input[position] = 15;
	           break;
	        default:
	           data_input[position] = 0;
	           break;
    	}
    	position = position + 1;
	}
	if(data_len == 2)
	{
		gpioData = 16 * data_input[0] + data_input[1];
	}
	else
	{
		gpioData = data_input[0];
	}
    XGpio_DiscreteWrite(&LEDs, LEDS_CHANNEL, gpioData);
}
