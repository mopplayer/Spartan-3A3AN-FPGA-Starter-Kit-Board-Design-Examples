/*****************************************************************************
**                                                                          **
**     XILINX IS PROVIDING THIS DESIGN, CODE, OR INFORMATION "AS IS"        **
**     SOLELY FOR USE IN DEVELOPING PROGRAMS AND SOLUTIONS FOR              **
**     XILINX DEVICES.  BY PROVIDING THIS DESIGN, CODE, OR INFORMATION      **
**     AS ONE POSSIBLE IMPLEMENTATION OF THIS FEATURE, APPLICATION          **
**     OR STANDARD, XILINX IS MAKING NO REPRESENTATION THAT THIS            **
**     IMPLEMENTATION IS FREE FROM ANY CLAIMS OF INFRINGEMENT,              **
**     AND YOU ARE RESPONSIBLE FOR OBTAINING ANY RIGHTS YOU MAY REQUIRE     **
**     FOR YOUR IMPLEMENTATION.  XILINX EXPRESSLY DISCLAIMS ANY             **
**     WARRANTY WHATSOEVER WITH RESPECT TO THE ADEQUACY OF THE              **
**     IMPLEMENTATION, INCLUDING BUT NOT LIMITED TO ANY WARRANTIES OR       **
**     REPRESENTATIONS THAT THIS IMPLEMENTATION IS FREE FROM CLAIMS OF      **
**     INFRINGEMENT, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS      **
**     FOR A PARTICULAR PURPOSE.                                            **
**                                                                          **
**     (c) Copyright 2003 Xilinx, Inc.                                      **
**     All rights reserved.                                                 **
**                                                                          **
/*****************************************************************************
**                                                                          **
**  Filename: lcd.h                                                         **
**                                                                          **
**  Description:                                                            **
**    2 Line by 16 Character LCD Display Driver header                      **
**                                                                          **
**  Design Notes:                                                           **
**                                                                          **
**     ML40x use a Samsung S6A0069 controller in 4-bit mode                 **
**     ML410 use a Hitachi HD44780U controller in 8-bit mode                **
**                                                                          **
**                                                                          **
******************************************************************************
**  History                                                                 **
**                                                                          **
*****************************************************************************/

#ifndef  LCD_H
#define  LCD_H  1

#if LCD_8BIT

#define  LCD_SET   0x38 	// b00111000  function set, 8 bit, 2 line, 5x8

#else

#define  LCD_SET   0x28		// b00101000  function set, 4 bit, 2 line, 5x8

#endif  // if LCD_8BIT

#define  LCD_RS    0x80

#define  LCD_ON    0x0C 	// b00001100  display on, cursor off, blink off
#define  LCD_OFF   0x08 	// b00001000  display off
#define  LCD_CLR   0x01 	// b00000001  clear display
#define  LCD_MODE  0x06 	// b00000110  entry mode, increment, no shift
#define  LCD_L1    0x80 	// b10000000  beginning of line 1
#define  LCD_L2    0xC0 	// b11000000  beginning of line 2

void lcd_init  (Xuint32 BaseAddr);
void lcd_clear (Xuint32 BaseAddr);
void lcd_print (Xuint32 BaseAddr, Xuint32 Line, Xuint8 *Str);

#endif  // if LCD_H

