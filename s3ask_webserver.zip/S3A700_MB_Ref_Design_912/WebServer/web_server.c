/*
 * XILINX IS PROVIDING THIS DESIGN, CODE, OR INFORMATION "AS IS"
 * SOLELY FOR USE IN DEVELOPING PROGRAMS AND SOLUTIONS FOR
 * XILINX DEVICES.  BY PROVIDING THIS DESIGN, CODE, OR INFORMATION
 * AS ONE POSSIBLE IMPLEMENTATION OF THIS FEATURE, APPLICATION
 * OR STANDARD, XILINX IS MAKING NO REPRESENTATION THAT THIS
 * IMPLEMENTATION IS FREE FROM ANY CLAIMS OF INFRINGEMENT,
 * AND YOU ARE RESPONSIBLE FOR OBTAINING ANY RIGHTS YOU MAY REQUIRE
 * FOR YOUR IMPLEMENTATION.  XILINX EXPRESSLY DISCLAIMS ANY
 * WARRANTY WHATSOEVER WITH RESPECT TO THE ADEQUACY OF THE
 * IMPLEMENTATION, INCLUDING BUT NOT LIMITED TO ANY WARRANTIES OR
 * REPRESENTATIONS THAT THIS IMPLEMENTATION IS FREE FROM CLAIMS OF
 * INFRINGEMENT, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE.
 *
 * (c) Copyright 2005 Xilinx, Inc.
 * All rights reserved.
 *
 */

/* License declaration for the lwIP library follows */

/*
 * Copyright (c) 2001, 2002, 2003 Swedish Institute of Computer Science.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN
 * NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
 * TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

/*
 * Modification history:
 *    12/2005 - Rob Armstrong - Xilinx, Inc.
 *            - Initial File Version
 */

/* Xilinx Includes */
#include "web_server.h"
#include "http.h"
#include "mfs_config.h"    // Required for the Xilinx Memory File System
#include "xstatus.h"       // Required for status checks on peripheral functions
#include "xgpio.h"         // Required for GPIO peripherals
#include "xmk.h"
#include <lcd.h>

/* C Library Includes */
#include "string.h"        // Required for memset and strtok

/* lwIP Includes */
#include "netif/xemacif.h"
#include "lwip/tcpip.h"
#include "lwip/memp.h"
#include "netif/etharp.h"
#include "lwip/sys.h"
#include "lwip/sockets.h"

/* External Declarations */
extern XEmacIf_Config XEmacIf_ConfigTable[];

/* Instance Pointers for Xilinx Peripherals */
XGpio PushButtons;
XGpio LEDs;

/* Global variable for connections */
int numConnections;

/* void* processConnection(void* arg)
 *
 * Receives and responds to HTTP requests from the remote
 * web client.
 */
void* processConnection(void* arg)
{
    char receiveBuffer[RECV_BUFFER_LENGTH];
    char *methodPtr;
    char *dataPtr;
    char *typePtr;
    int sd = *((int*) arg);
    int bytesReceived;

    // Read the request from the socket into the receive buffer
    bytesReceived = read(sd, receiveBuffer, RECV_BUFFER_LENGTH);

    // Tokenize the received request
    methodPtr = strtok(receiveBuffer, " ");
    dataPtr = strtok((char *)NULL, " ");
    typePtr = strtok((char *)NULL, "\r");

    xil_printf("Processing %s %s request for %s\r\n", typePtr, methodPtr, dataPtr);

    if(!strcmp(methodPtr, "GET")) {
        processGet(sd, dataPtr);
    }

    close(sd);
    numConnections--;
}

/* void* serverAppThread(void* arg)
 *
 * Initializes the TCP/IP settings and accepts incoming connections.
 */
void* serverAppThread(void* arg)
{
    int i;
    int leds_disp;
    int buttons_value;
    int sock;
    int new_sd;
    int size;
    unsigned char macaddr[6];
    unsigned char ip_address[4];
    unsigned char gateway_addr[4];
    unsigned char subnet[4];
    struct ip_addr ipaddr, netmask, gateway;
    struct netif *server_netif;
    struct sockaddr_in address, remote;
    XEmacIf_Config *xemacif_ptr = &XEmacIf_ConfigTable[0];

    // Clear the screen and print the legal header for the reference design
    clearScreen();
    printLegalHeader();

    // Set up the MAC address for the ethernet MAC
    getMacAddr(macaddr);
    xemacif_setmac(0, (u8_t *)macaddr);

    // Read in and set the IP address, Subnet Mask, and Gateway
    readIPSetup(ip_address, subnet, gateway_addr);
    IP4_ADDR(&ipaddr, ip_address[0], ip_address[1], ip_address[2], ip_address[3]);
   	IP4_ADDR(&netmask, subnet[0], subnet[1], subnet[2], subnet[3]);
    IP4_ADDR(&gateway, gateway_addr[0], gateway_addr[1], gateway_addr[2], gateway_addr[3]);

    // Display the configuration options
    clearScreen();
    displayConfiguration(macaddr, ip_address, subnet, gateway_addr);

    // Set up the lwIP network interface
    // Allocate and configure the server's netif
    server_netif = mem_malloc(sizeof(struct netif));
    if(server_netif == NULL)
    {
        xil_printf("ERROR: netif_add(): Out of memory for default netif\n\r");
        return;
    }
    server_netif = netif_add(server_netif,
                             &ipaddr,
                             &netmask,
                             &gateway,
                             &XEmacIf_ConfigTable[0],
                             xemacif_init,
                             tcpip_input);
    netif_set_default(server_netif);

    // Register the XEMAC interrupt handler with the controller and enable
    // interrupts within XMK
    register_int_handler(EMAC_INTERRUPT_ID,
                         (XInterruptHandler)XEmac_IntrHandlerFifo,
                         xemacif_ptr->instance_ptr);
    enable_interrupt(EMAC_INTERRUPT_ID);

    // Create and bind the socket. Because the MicroBlaze and PowerPC processors
    // are big-endian architectures, the calls to htons(), htonl(), etc. aren't
    // necessary, but are included for completeness and portability
    sock = socket(AF_INET, SOCK_STREAM, 0);
    address.sin_family      = AF_INET;
    address.sin_port        = htons(HTTP_PORT);
    address.sin_addr.s_addr = INADDR_ANY;
    bind(sock, (struct sockaddr*)&address, sizeof(address));

    xil_printf("Server initialization complete.\r\n");
    xil_printf("HTTP server is now accepting new connections on port %d\r\n", HTTP_PORT);

    // Begin listening on the socket. For all new connections, spawn a new
    // thread, processConnection(), to deal with them
    listen(sock, 4);
    numConnections = 0;
    while(1)
    {
        size = sizeof(remote);
        new_sd = accept(sock, (struct sockaddr *)&remote, &size);
        xil_printf("New HTTP connection accepted\n\r");
        numConnections++;

        // Spawn a new thread to handle the data for the new connection
        sys_thread_new((void *)&processConnection, &new_sd, numConnections);
    }
}

/* void* serverThread(void* arg)
 *
 * Initializes the lwIP library and spawns the web server main task
 */
void* serverThread(void* arg)
{
    // Initialize the lwIP library
    xil_printf("Initializing the lwIP library...\r\n");
    lwip_init();
    // Sleep to allow lwIP initialization status messages to display
    // without interruption
    sleep(100);
    xil_printf("lwIP initialization done\n\r");

    // Spawn the web server application thread
    sys_thread_new((void *)&serverAppThread, 0, 0);
}


void* lcdThread(void* arg)
{
	Xuint32 pressed;
	Xuint32 rotary;
	char display[15];

	while (1) {
		rotary = XIo_In32(ROT_SWITCH_ADDR);

		if ( rotary == 0x00000001 ) {
			strcpy(display, "Message #01");
			} else if ( rotary == 0x00000002 ) {
				strcpy(display, "Message #02");
			} else if ( rotary == 0x00000004 ) {
				strcpy(display, "Message #03");
			} else if ( rotary == 0x00000008 ) {
				strcpy(display, "Message #04");
			} else if ( rotary == 0x00000010 ) {
				strcpy(display, "Message #05");
			} else if ( rotary == 0x00000020 ) {
				strcpy(display, "Message #06");
			} else if ( rotary == 0x00000040 ) {
				strcpy(display, "Message #07");
			} else if ( rotary == 0x00000080 ) {
				strcpy(display, "Message #08");
			} else if ( rotary == 0x00000100 ) {
				strcpy(display, "Message #09");
			} else if ( rotary == 0x00000200 ) {
				strcpy(display, "Message #10");
			} else if ( rotary == 0x00000400 ) {
				strcpy(display, "Message #11");
			} else if ( rotary == 0x00000800 ) {
				strcpy(display, "Message #12");
			} else if ( rotary == 0x00001000 ) {
				strcpy(display, "Message #13");
			} else if ( rotary == 0x00002000 ) {
				strcpy(display, "Message #14");
			} else if ( rotary == 0x00004000 ) {
				strcpy(display, "Message #15");
			} else {
				strcpy(display, "Message #16");
			}

		lcd_print(LCD_ADDR, 1, display);
		pressed = XIo_In32(ROT_PRESS_ADDR);

		if (pressed == 0x00000001) {
			lcd_print(LCD_ADDR, 2, display);
		}
	}
}


/* int main(void)
 *
 * Initializes the memory file system from an image pre-loaded in SRAM, and
 * launches the Xilinx MicroKernel.
 */
int main(void)
{
    XStatus status;

	 /*
    * Enable and initialize cache
    */
   #if XPAR_MICROBLAZE_0_USE_ICACHE
      microblaze_init_icache_range(0, XPAR_MICROBLAZE_0_CACHE_BYTE_SIZE);
      microblaze_enable_icache();
   #endif

    // Clear the screen to get rid of anything that may initially have
    // been displayed on the user's terminal
    clearScreen();

    xil_printf("Xilinx Web Server Demonstration (v2.0), S3A-Kit\r\n");
    xil_printf("(c) Xilinx, Inc. 2005\r\n\r\n");
    xil_printf("System Initialization in progress:\r\n\r\n");

    // Initialize the MFS image. The additional 4 byte offset is to account
    // for the 4 byte header at the top of the MFS data, which is not
    // automatically skipped
    xil_printf("Initializing MFS...");
    mfs_init_fs(MFS_NUMBYTES, (char *)(MFS_BASE_ADDRESS+4), MFS_INIT_TYPE);
    xil_printf("done\r\n");
    mfs_ls_r(1);

    // Initialize the GPIO instances for the push buttons and LEDs
    xil_printf("Initializing GPIO...");
    status = XGpio_Initialize(&PushButtons, BUTTONS_DEVICE_ID);
    if(status != XST_SUCCESS) {
        xil_printf("\r\nERROR: Unable to initialize push buttons\r\n");
        return -1;
    }
    status = XGpio_Initialize(&LEDs, LEDS_DEVICE_ID);
    if(status != XST_SUCCESS) {
        xil_printf("\r\nERROR: Unable to initialize LEDs\r\n");
        return -1;
    }
    XGpio_SetDataDirection(&PushButtons, SWITCHES_CHANNEL, BUTTONS_DATA_DIRECTION);
    XGpio_SetDataDirection(&LEDs, LEDS_CHANNEL, LEDS_DATA_DIRECTION);

    // Turn the LEDs on (active high)
    XGpio_DiscreteWrite(&LEDs, LEDS_CHANNEL, 0x000000FF);
    xil_printf("done\r\n");

    // Launch XMK
    xilkernel_main();

    return 0;
}
