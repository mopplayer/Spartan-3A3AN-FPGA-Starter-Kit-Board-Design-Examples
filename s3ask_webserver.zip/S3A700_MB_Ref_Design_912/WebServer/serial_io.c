/*
 * XILINX IS PROVIDING THIS DESIGN, CODE, OR INFORMATION "AS IS"
 * SOLELY FOR USE IN DEVELOPING PROGRAMS AND SOLUTIONS FOR
 * XILINX DEVICES.  BY PROVIDING THIS DESIGN, CODE, OR INFORMATION
 * AS ONE POSSIBLE IMPLEMENTATION OF THIS FEATURE, APPLICATION
 * OR STANDARD, XILINX IS MAKING NO REPRESENTATION THAT THIS
 * IMPLEMENTATION IS FREE FROM ANY CLAIMS OF INFRINGEMENT,
 * AND YOU ARE RESPONSIBLE FOR OBTAINING ANY RIGHTS YOU MAY REQUIRE
 * FOR YOUR IMPLEMENTATION.  XILINX EXPRESSLY DISCLAIMS ANY
 * WARRANTY WHATSOEVER WITH RESPECT TO THE ADEQUACY OF THE
 * IMPLEMENTATION, INCLUDING BUT NOT LIMITED TO ANY WARRANTIES OR
 * REPRESENTATIONS THAT THIS IMPLEMENTATION IS FREE FROM CLAIMS OF
 * INFRINGEMENT, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE.
 *
 * (c) Copyright 2005 Xilinx, Inc.
 * All rights reserved.
 *
 */

/*
 * Modification history:
 *    12/2005 - Rob Armstrong - Xilinx, Inc.
 *            - Initial File Version
 */

/* Xilinx Includes */
#include "web_server.h"
#include "xuartlite_l.h"
#include "stdlib.h"

/* void printLegalHeader(void)
 *
 * Displays the Xilinx reference design legal header to stdout.
 */
void printLegalHeader(void)
{
	xil_printf("####################################################################\r\n");
	xil_printf("# Xilinx lwIP TCP/IP Demo Application (Web Server) v2.0            #\r\n");
	xil_printf("#                                                                  #\r\n");
	xil_printf("# XILINX IS PROVIDING THIS DESIGN, CODE, OR INFORMATION \"AS IS\"    #\r\n");
	xil_printf("# SOLELY FOR USE IN DEVELOPING PROGRAMS AND SOLUTIONS FOR          #\r\n");
	xil_printf("# XILINX DEVICES.                                                  #\r\n");
	xil_printf("#                                                                  #\r\n");
	xil_printf("# (c) Copyright 2005 Xilinx, Inc.                                  #\r\n");
	xil_printf("# All rights reserved                                              #\r\n");
	xil_printf("#                                                                  #\r\n");
	xil_printf("####################################################################\r\n");
	xil_printf("\n\r\n");
}

/* void printByteDashedHex(unsigned char* buffer, int length)
 *
 * Displays the contents of a byte array as a dash-delimited string
 * to STDOUT
 */
void printByteDashedHex(unsigned char* buffer, int length)
{
    unsigned char* loop;

    for(loop = buffer; loop < (buffer + length - 1); loop++) {
        xil_printf("%02X-", *loop);
    }
    xil_printf("%02X", *loop);
}

/* void printDottedDecimal(unsigned char* buffer, int length)
 *
 * Displays the contents of a byte array as a dot delimited string
 * to STDOUT
 */
void printDottedDecimal(unsigned char* buffer, int length)
{
    int loop;
    for(loop = 0; loop < length; loop++) {
        if(loop != 0) {
            xil_printf(".");
        }
        xil_printf("%d", buffer[loop]);
    }
}

/* void getMacAddr(unsigned char* address)
 *
 * Read and format a 6 byte MAC address from STDIN. The calling function
 * is responsible for allocating the memory required to store the MAC
 * address
 */
void getMacAddr(unsigned char* address)
{
    unsigned char character;
    unsigned char last[6];
    int index;

    // Ensure that the address buffer is zeroed
    memset(address, 0, 6);

	// MAC Address
    address[0] = 0x01;
    address[1] = 0x02;
    address[2] = 0x03;
	address[3] = 0x04;
    address[4] = 0x05;
    address[5] = 0x06;

}

/* void clearScreen(void)
 *
 * Prints 24 newline characters to clear the display, assuming a standard 80x24
 * display
 */
void clearScreen(void)
{
    xil_printf("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\r\n");
}

/* void readIPSetup(unsigned char* ip_address, unsigned char* subnet, unsigned char* gateway)
 *
 * Read the three IP address configuraiton settings from the console to
 * populate the buffers.
 */
void readIPSetup(unsigned char* ip_address, unsigned char* subnet, unsigned char* gateway)
{
    xil_printf("\r\nThis demonstration requires manual entry of your IP configuration\r\n");
    xil_printf("settings. Please fill in the following fields:\r\n\r\n");
    xil_printf("IP Address : ");
    while(readIP(ip_address) == FALSE) {
        xil_printf("IP Address : ");
    }
    xil_printf("Subnet Mask: ");
    while(readIP(subnet) == FALSE) {
        xil_printf("Subnet Mask: ");
    }
    xil_printf("Gateway    : ");
    while(readIP(gateway) == FALSE) {
        xil_printf("Gateway    : ");
    }
}

/* int readIP(unsigned char* ip_address)
 *
 * Read and format an IP address from the console, and return a four-byte buffer
 * containing the address
 */
int readIP(unsigned char* ip_address)
{
    unsigned char address[5];
    unsigned char character;
    int index;
    int charcount;

    // Ensure that the buffers are initialized to zeros
    memset(ip_address, 0, 4);
    memset(address, 0, 5);

    // Loop through the IP address to read in the values
    index = 0;
    charcount = 0;
    while(index < 4) {
       while(charcount < 3) {
           character = XUartLite_RecvByte(UART_ADDRESS);
           // Process numeric (1-9) characters
           if((character > 47) && (character < 58)) {
               address[charcount] = character;
               XUartLite_SendByte(UART_ADDRESS, character);
               charcount++;
           }
           // Process '.', '\r', and '\n' characters
           else if((character == '.') || (character == '\r') || (character == '\n')) {
               // Stop reading in additional characters for this segment
               if(charcount != 0) {
                   break;
               }
           }
       }
       // Delimit the fields with a '.' character
       if(index != 3) {
           XUartLite_SendByte(UART_ADDRESS, '.');
       }

       // Format and store this byte of the address
       ip_address[index] = (unsigned char)atoi(address);
       memset(address, 0, 5);
       index++;
       charcount = 0;
    }

    // Check with the user whether or not the address is correct
    xil_printf("\r\nIs the address ");
    printDottedDecimal(ip_address, 4);
    xil_printf(" correct? (y/n)");

    // Loop until we get a valid response
    while(1) {
        character = XUartLite_RecvByte(UART_ADDRESS);
        if((character == 'Y') || (character == 'y')) {
            xil_printf("\r\n");
            return TRUE;
        }
        else if((character == 'N') || (character == 'n')) {
            xil_printf("\r\n");
            return FALSE;
        }
    }
}

/* void displayConfiguration(unsigned char* mac_address,
 *                           unsigned char* ip_address,
 *                           unsigned char* subnet,
 *                           unsigned char* gateway)
 *
 * Displays all of the currently set configuration options for the web server
 * along with a header
 */
void displayConfiguration(unsigned char* mac_address,
                          unsigned char* ip_address,
                          unsigned char* subnet,
                          unsigned char* gateway)
{
    xil_printf("####################################################################\r\n");
	xil_printf("# Xilinx lwIP TCP/IP Demo Application (Web Server) v2.0            #\r\n");
	xil_printf("#                                                                  #\r\n");
	xil_printf("# Web Server is now configured and accepting connections.          #\r\n");
	xil_printf("#                                                                  #\r\n");
	xil_printf("# If you have not purchased a license for the EMAC core, please    #\r\n");
	xil_printf("# note that you are currently using a hardware evaluation license  #\r\n");
	xil_printf("# which will stop operating in approximately 8 hours.              #\r\n");
	xil_printf("#                                                                  #\r\n");
	xil_printf("####################################################################\r\n");
	xil_printf("\r\nMAC Address: ");
	printByteDashedHex(mac_address, 6);
	xil_printf("\r\nIP Address : ");
	printDottedDecimal(ip_address, 4);
	xil_printf("\r\nSubnet Mask: ");
	printDottedDecimal(subnet, 4);
	xil_printf("\r\nGateway    : ");
	printDottedDecimal(gateway, 4);
	xil_printf("\r\n\r\n");
}
