/*
 * XILINX IS PROVIDING THIS DESIGN, CODE, OR INFORMATION "AS IS"
 * SOLELY FOR USE IN DEVELOPING PROGRAMS AND SOLUTIONS FOR
 * XILINX DEVICES.  BY PROVIDING THIS DESIGN, CODE, OR INFORMATION
 * AS ONE POSSIBLE IMPLEMENTATION OF THIS FEATURE, APPLICATION
 * OR STANDARD, XILINX IS MAKING NO REPRESENTATION THAT THIS
 * IMPLEMENTATION IS FREE FROM ANY CLAIMS OF INFRINGEMENT,
 * AND YOU ARE RESPONSIBLE FOR OBTAINING ANY RIGHTS YOU MAY REQUIRE
 * FOR YOUR IMPLEMENTATION.  XILINX EXPRESSLY DISCLAIMS ANY
 * WARRANTY WHATSOEVER WITH RESPECT TO THE ADEQUACY OF THE
 * IMPLEMENTATION, INCLUDING BUT NOT LIMITED TO ANY WARRANTIES OR
 * REPRESENTATIONS THAT THIS IMPLEMENTATION IS FREE FROM CLAIMS OF
 * INFRINGEMENT, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE.
 *     
 * (c) Copyright 2005 Xilinx, Inc.
 * All rights reserved.
 *
 */
 
/*
 * Modification history:
 *    12/2005 - Rob Armstrong - Xilinx, Inc.
 *            - Initial File Version
 */
 
#ifndef _WS_SERIO_
#define _WS_SERIO_
 
/* Function prototypes for serial_io.c */
void printLegalHeader(void);
void printByteDashedHex(unsigned char* buffer, int length);
void getMacAddr(unsigned char* address);
void clearScreen(void);
int useDHCP(void);
void readIPSetup(unsigned char* ip_address, unsigned char* subnet, unsigned char* gateway);
int readIP(unsigned char* ip_address);
void printDottedDecimal(unsigned char* buffer, int length);
void displayConfiguration(unsigned char* mac_address,
                          unsigned char* ip_address,
                          unsigned char* subnet,
                          unsigned char* gateway);

#endif
