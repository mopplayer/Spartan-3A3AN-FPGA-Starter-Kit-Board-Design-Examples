#define TESTAPP_GEN

#include "xbasic_types.h"
#include "xstatus.h"

XStatus EmacIntrExample(XIntc *IntcInstancePtr,
                        XEmac *EmacInstancePtr,
                        Xuint16 EmacDeviceId,
                        Xuint16 EmacIntrId);


