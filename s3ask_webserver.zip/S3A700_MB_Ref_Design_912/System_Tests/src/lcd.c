/*****************************************************************************
**                                                                          **
**     XILINX IS PROVIDING THIS DESIGN, CODE, OR INFORMATION "AS IS"        **
**     SOLELY FOR USE IN DEVELOPING PROGRAMS AND SOLUTIONS FOR              **
**     XILINX DEVICES.  BY PROVIDING THIS DESIGN, CODE, OR INFORMATION      **
**     AS ONE POSSIBLE IMPLEMENTATION OF THIS FEATURE, APPLICATION          **
**     OR STANDARD, XILINX IS MAKING NO REPRESENTATION THAT THIS            **
**     IMPLEMENTATION IS FREE FROM ANY CLAIMS OF INFRINGEMENT,              **
**     AND YOU ARE RESPONSIBLE FOR OBTAINING ANY RIGHTS YOU MAY REQUIRE     **
**     FOR YOUR IMPLEMENTATION.  XILINX EXPRESSLY DISCLAIMS ANY             **
**     WARRANTY WHATSOEVER WITH RESPECT TO THE ADEQUACY OF THE              **
**     IMPLEMENTATION, INCLUDING BUT NOT LIMITED TO ANY WARRANTIES OR       **
**     REPRESENTATIONS THAT THIS IMPLEMENTATION IS FREE FROM CLAIMS OF      **
**     INFRINGEMENT, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS      **
**     FOR A PARTICULAR PURPOSE.                                            **
**                                                                          **
**     (c) Copyright 2003 Xilinx, Inc.                                      **
**     All rights reserved.                                                 **
**                                                                          **
/*****************************************************************************
**                                                                          **
**  Filename: lcd.c                                                         **
**                                                                          **
**  Description:                                                            **
**    2 Line by 16 Character LCD Display Driver                             **
**                                                                          **
**  Design Notes:                                                           **
**                                                                          **
**     ML40x use a Samsung S6A0069 controller in 4-bit mode                 **
**     ML410 use a Hitachi HD44780U controller in 8-bit mode                **
**                                                                          **
******************************************************************************
**  History                                                                 **
**                                                                          **
*****************************************************************************/

#include "xparameters.h"
#include "xbasic_types.h"
#include "xstatus.h"
#include "xutil.h"
#include "lcd.h"


volatile Xuint8 *LCD_Data = (Xuint8 *)(XPAR_CHAR_LCD_BASEADDR + 0x00);
volatile Xuint8 *LCD_Cmd  = (Xuint8 *)(XPAR_CHAR_LCD_BASEADDR + 0x04);




void lcd_cmd (Xuint32 BaseAddr, Xuint8 Val) 
{
   *LCD_Cmd = (Xuint32)Val;
}



void lcd_data (Xuint32 BaseAddr, Xuint8 Val) 
{
   *LCD_Data = (Xuint32)Val;
}



// Initialize LCD
void lcd_init(Xuint32 BaseAddr) 
{
int i;

   lcd_cmd(BaseAddr, LCD_SET);
   lcd_cmd(BaseAddr, LCD_SET);
   lcd_cmd(BaseAddr, LCD_SET);
   lcd_cmd(BaseAddr, LCD_ON);
   lcd_cmd(BaseAddr, LCD_CLR); 
   lcd_cmd(BaseAddr, LCD_MODE);
}



void lcd_clear (Xuint32 BaseAddr) 
{
   lcd_cmd (BaseAddr, LCD_CLR); 
}



void lcd_print (Xuint32 BaseAddr, Xuint32 Line, Xuint8 *Str) 
{
   if (Line == 1)
      lcd_cmd(BaseAddr, LCD_L1);
   else
      lcd_cmd(BaseAddr, LCD_L2);

   while (*Str)
      lcd_data(BaseAddr, *Str++);
}


