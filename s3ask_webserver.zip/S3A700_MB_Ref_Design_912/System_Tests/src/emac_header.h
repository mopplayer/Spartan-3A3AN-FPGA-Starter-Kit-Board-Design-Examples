#define TESTAPP_GEN

/* $Id: emac_header.h,v 1.1 2006/03/08 22:48:51 jibinh Exp $ */


#include "xbasic_types.h"
#include "xstatus.h"

XStatus EmacPolledExample(Xuint16 DeviceId);


