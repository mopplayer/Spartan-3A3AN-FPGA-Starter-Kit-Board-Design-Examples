
// Located in: microblaze_0/include/xparameters.h
#include "xparameters.h"
#include "mb_interface.h"
#include "stdio.h"
#include "lcd.h"
#include "xbasic_types.h"
#include "xgpio.h"
#include "xintc.h"
#include "xemac.h"
#include "emac_header.h"
#include "emac_intr_header.h"


//====================================================

int main (void) {
    
	Xuint32 rotary_input, rotary_push;
	Xuint8 led_data;
   XStatus Status;
	int i;
	static XIntc intc;
	static XEmac Ethernet_MAC_Emac;

   /*
    * Enable and initialize cache
    */
   #if XPAR_MICROBLAZE_0_USE_ICACHE
      microblaze_init_icache_range(0, XPAR_MICROBLAZE_0_CACHE_BYTE_SIZE);
      microblaze_enable_icache();
   #endif

	#if XPAR_MICROBLAZE_0_USE_DCACHE
      microblaze_init_dcache_range(0, XPAR_MICROBLAZE_0_DCACHE_BYTE_SIZE);
      microblaze_enable_dcache();
   #endif


	lcd_init(XPAR_CHAR_LCD_BASEADDR);
	lcd_clear(XPAR_CHAR_LCD_BASEADDR);

   print("-- Entering main() --\r\n");
	lcd_print(XPAR_CHAR_LCD_BASEADDR, 1, "System Tests...");

	 /*
     * Run the Emac Interrupt-Polled example , specify the Device ID that is
     * generated in xparameters.h
     */
	{
      XStatus status;
      
      print("\r\nRunning EmacPolledExample() for Ethernet_MAC...\r\n");
      status = EmacPolledExample(XPAR_ETHERNET_MAC_DEVICE_ID);
      if (status == 0) {
         print("EmacPolledExample PASSED\r\n");
      }
      else {
         print("EmacPolledExample FAILED\r\n");
      }
   }

	  /*
     * Run the Emac Interrupt-FIFO example , specify the Device ID that is
     * generated in xparameters.h
     */
	{
      XStatus Status;

      print("\r\nRunning EmacIntrExample() for Ethernet_MAC...\r\n");
      Status = EmacIntrExample(&intc, &Ethernet_MAC_Emac, \
                               XPAR_ETHERNET_MAC_DEVICE_ID, \
                               XPAR_OPB_INTC_0_ETHERNET_MAC_IP2INTC_IRPT_INTR);
      if (Status == 0) {
         print("Emac Interrupt Test PASSED.\r\n");
			lcd_print(XPAR_CHAR_LCD_BASEADDR, 2, "Eth Tests Passed");
      } 
      else {
         print("Emac Interrupt Test FAILED.\r\n");
			lcd_print(XPAR_CHAR_LCD_BASEADDR, 2, "Eth Tests Failed");
      }
   }

    
	// Use the Rotary switch to toggle the LEDs
	// Pushing the Rotary button will exit the loop
	rotary_push = XIo_In32(XPAR_OPB_ROT_SWITCH_0_BASEADDR + 4);
	
	while (1) {
		for (i=1000; i >0; --i); 
		// Rotary data is returned on the 16 least significant bits
		rotary_input = XIo_In32(XPAR_OPB_ROT_SWITCH_0_BASEADDR);
		
		// LED is only 8-bit wide. Use lower and upper 8-bits of data from the rotary switch
		led_data = (Xuint8)(rotary_input & 0x000000FF) | (Xuint8)((rotary_input & 0x0000FF00) >> 8 );

		// Output to LEDs
		XGpio_mSetDataReg(XPAR_LEDS_8BIT_BASEADDR, XGPIO_IR_CH1_MASK, led_data); 

		// Sample Rotary push
		rotary_push = XIo_In32(XPAR_OPB_ROT_SWITCH_0_BASEADDR + 4);
		
		if (rotary_push == 0x00000001) break;
		}

	// Start Second boot - Uncomment for dual boot configuration
	//XIo_Out32(XPAR_OPB_S3A_ICAP_0_BASEADDR, 0x00080000);

   return 0;
}

