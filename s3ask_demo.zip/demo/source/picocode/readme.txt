You must separately obtain the PicoBlaze assembler for Spartan-3 Generation
FPGA devices from http://www.xilinx.com/picoblaze.  The following files
are required to be located in this directory:

kcpsm3.exe
ROM_form.coe
ROM_form.v
ROM_form.vhd