You must separately obtain the PicoBlaze source for Spartan-3 Generation
FPGA devices from http://www.xilinx.com/picoblaze.  The following files
must be added to this directory:

bbfifo_16x8.vhd
kcpsm3.vhd
kcuart_rx.vhd
kcuart_tx.vhd
uart_rx.vhd
uart_tx.vhd