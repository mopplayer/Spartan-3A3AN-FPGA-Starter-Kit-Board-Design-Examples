This archive contains the complete source to the out-of-box demo. 
mcs_files/  Directory containing a script to generate final mcs files. 
demo/       Source files and implementation scripts for main demo. 
dna_read/   Source files and implementation scripts for DeviceDNA reader. 
flashprog/  Source files and implementation scripts for Flash programmer. 
fractal/    Source files and implementation scripts for VGA Fractal demo. 
terminal/   Source files and implementation scripts for ASCII Terminal demo. 
Please consult the out-of-box demo documentation for additional information. 
Thu 03/29/2007 
