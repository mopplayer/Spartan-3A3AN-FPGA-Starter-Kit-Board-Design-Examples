You must separately obtain the PicoBlaze source for Spartan-3 Generation
FPGA devices from http://www.xilinx.com/picoblaze.  The following files
must be added to this directory:

bbfifo_16x8.v
kcpsm3.v
kcuart_rx.v
kcuart_tx.v
uart_rx.v
uart_tx.v