This folder has the batch files to synthesize using the XST or Synplify Pro
and PAR the design through command mode.

Steps to run the design using the ise flow :

1. Double clicking the ise_flow.bat file, synthesizes the design using
   XST or Synplify Pro and does the PAR.

2. On running the ise_flow.bat file, creates the all report files.

Steps to run the design using the create_ise (GUI mode - for XST cases only):

1. This file will appear for XST cases only.

2. Double clicking the create_ise.bat file, it creates test.ise project file
   by setting all the properties of the design selected.

3. Once the test.ise project file is created, you can open the project file
   and synthesize and run the PAR.

About other files in PAR folder :

* vlog_bl8.ucf file is the constratint file for the design. This is used
  by ISE tool during PAR phase. It has all the clock constraints,
  Location constraints, false paths if any, IO standards and
  Area group constraints if any.

* ise_run.txt file has synthesis options for the XST tool.

* mem_interface_top.ut file has the options for the Configuration file
  generation i.e. the .bit file.


* "set_ise_props.txt" file has all the properties that needs to be set
  in GUI mode. This file will appear only for XST cases.

* "icon_coregen.xco" and "ila_coregen.xco" files are used to
  generate chipscope ila and icon EDIF/NGC files. view the design signals
  on chipscope, you should port the design signals to chipscope modules
  i.e., ila and icon and set DEBUG_EN parameter to 1 in vlog_bl8 rtl file.
  In order to generate the EDIF/NGC files, you must execute the following
  commands before starting systhesis and PAR.

        coregen -b ila_coregen.xco
        coregen -b icon_coregen.xco
        coregen -b vio_coregen.xco

Note : When you generate the design usign DEBUG_EN option, the above mentioned
       chipscope coregen commands are printed into ise_flow.bat and
       create_ise.bat files. The vlog_bl8 rtl file will have the design
       debug signals portmapped to ila and icon chipscope modules.

Synth folder:

* Synth folder has the constraint file for synplify Pro designs i.e.
  the .sdc file, Project file which has the design files to be added to
  the project i.e. the .prj file  and the synthesis tool options file for
  synplify Pro i.e. .tcl file.

compatible_ucf folder:

* MIG outputs this folder only when Pin Compatible FPGAs are checked in GUI
  (Pin Compatible FPGAs page in GUI). It generates the UCF files for the all
  the Compatible FPGAs selected in GUI. If you want to switch to any of the
  Compatible FPGAs follow the steps mentioned below.

* For example, the design is generated with component name as mig_22 with
  Target FPGA 4000FG1156 and Compatible FPGA 5000FG1156.

   - Change the FPGA name to 5000FG1156 from 4000FG1156 in ise_flow.bat,
     create_ise.bat and xst_run.txt, set_ise_prop.txt in par folder and
     .tcl file in synth folder.
   - Paste the 5000FG1156.ucf file in par folder.
   - Change the UCF file name in batch file to the one in compatible_ucf
     folder i.e., change the UCF name (vlog_bl8.ucf) in ise_flow.bat and
     create_ise.bat file to XC3S4000_FG1156.ucf.
